#include<iostream>
using namespace std;
int main(){
    int a,b;
    cout<<"Enter a and b:";
    cin>> a>>b;
    cout<<"Sum of two numbers:"<<a+b;
}